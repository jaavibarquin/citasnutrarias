package es.nutrarias.citas.citasnutrarias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CitasNutrariasApplication {

	public static void main(String[] args) {
		SpringApplication.run(CitasNutrariasApplication.class, args);
	}

}
