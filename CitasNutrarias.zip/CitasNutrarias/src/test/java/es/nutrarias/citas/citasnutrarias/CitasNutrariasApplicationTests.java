package es.nutrarias.citas.citasnutrarias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitasNutrariasApplicationTests {

	@Test
	void contextLoads() {
	}

}
